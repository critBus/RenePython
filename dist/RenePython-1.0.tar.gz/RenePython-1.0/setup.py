from setuptools import setup
setup(

	name="RenePython",
	version="1.0",
	description="genial",
	author="Rene",
	author_email="renearteaga261998@gmail.com",
	packages=["Utiles","Utiles.MetodosUtiles","Utiles.ClasesUtiles","Utiles.ClasesUtiles.Tipos","Utiles.ClasesUtiles.BasesDeDatos","Utiles.ClasesUtiles.Interfaces","Utiles.MetodosUtiles.Imports"],
	url="www.google.com"
	
	)