
class TipoDeConexion:
    def __init__(self,valor):
        self.valor=valor
    def getValor(self):
        return self.valor

SQLITE=TipoDeConexion("sqlite")
POSTGRE_SQL=TipoDeConexion("postgres")
MY_SQL=TipoDeConexion("mysql")

#must be n, ne, e, se, s, sw, w, nw, or center
values=(SQLITE,POSTGRE_SQL,MY_SQL)

def esTipoDeConexion(a):
    return isinstance(a,TipoDeConexion)

def get(a):
    for i in values:
        if a==i.getValor():
            return i
    return None

def pertenece(a):
    return get(a)!=None