from Utiles.MetodosUtiles.MetodosUtiles import *
from datetime import datetime,date
class TipoDeDatoSQL:
    def __init__(self,valor,default):
        self._valor=valor
        self._default=default
    def getValor(self):
        return self._valor
    def getDefault(self):
        return self._default

INTEGER=TipoDeDatoSQL("INTEGER",0)
VARCHAR=TipoDeDatoSQL("VARCHAR","")
REAL=TipoDeDatoSQL("REAL",0)
DATE=TipoDeDatoSQL("DATE",datetime.now().date())
POINT=TipoDeDatoSQL("POINT",(0,0))
BOOLEAN=TipoDeDatoSQL("BOOLEAN",False)
DOUBLE_PRECISION=TipoDeDatoSQL("DOUBLE PRECISION",0)

#must be n, ne, e, se, s, sw, w, nw, or center
values=(INTEGER,VARCHAR,REAL,DATE,POINT,BOOLEAN,DOUBLE_PRECISION)

def esTipoDeDatoSQL(a):
    return isinstance(a,TipoDeDatoSQL)

def get(a):
    for i in values:
        if a==i.getValor():
            return i
    return None

def pertenece(a):
    return get(a)!=None
def getTipoDeDatoSQL(a):
    if esString(a):
        return VARCHAR
    elif esBool(a):
        return BOOLEAN
    elif esInt(a):
        return INTEGER
    elif esFloat(a):
        return DOUBLE_PRECISION
    return None