
class TipoDeClasificacionSQl:
    def __init__(self,valor):
        self.valor=valor
    def getValor(self):
        return self.valor

PRIMARY_KEY=TipoDeClasificacionSQl("PRIMARY KEY")
PRIMARY_KEY_AUTOINCREMENT=TipoDeClasificacionSQl("PRIMARY KEY AUTOINCREMENT")
UNIQUE=TipoDeClasificacionSQl("UNIQUE")
NOT_NULL=TipoDeClasificacionSQl("NOT NULL")
#must be n, ne, e, se, s, sw, w, nw, or center
values=(PRIMARY_KEY,PRIMARY_KEY_AUTOINCREMENT,UNIQUE)

def esTipoDeClasificacionSQl(a):
    return isinstance(a,TipoDeClasificacionSQl)

def get(a):
    for i in values:
        if a==i.getValor():
            return i
    return None

def pertenece(a):
    return get(a)!=None

def esLlave(a):
    return a==PRIMARY_KEY or a==PRIMARY_KEY_AUTOINCREMENT