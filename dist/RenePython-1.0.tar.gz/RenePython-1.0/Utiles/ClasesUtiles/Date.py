from Utiles.MetodosUtiles.Imports.MetodosUtilesBasicos import *
from datetime import datetime,date,time
#from calendar import
class Date():

    def  __init__(self,*a):
        self._año = 0
        self._mes = 1
        self._dia = 1
        self._hora = 0
        self._minuto = 0
        self._segundos = 0
        self._microsegundos = 0
        if len(a)==0:
            self.set(datetime.now())
        else:
            self.set(*a)


    def set(self,*a):

        leng = len(a)
        if leng==1:
            if esDatetimepy(a[0]):
                dat =a[0]
                self._año = dat.year
                self._mes = dat.month
                self._dia = dat.day
                self._hora = dat.hour
                self._minuto = dat.minute
                self._segundos = dat.second
                self._microsegundos =dat.microsecond
            elif esDatepy(a[0]):
                dat = a[0]
                self._año = dat.year
                self._mes = dat.month
                self._dia = dat.day
            elif esTimepy(a[0]):
                dat = a[0]
                self._hora = dat.hour
                self._minuto = dat.minute
                self._segundos = dat.second
                self._microsegundos = dat.microsecond
            elif esInt(a[0]):
                self._año = a[0]

        elif leng>1:
            datos=[self._año ,self._mes,self._dia ,self._hora ,self._minuto,self._segundos ,self._microsegundos ]
            for i in range(len(a)):
                datos[i]=a[i]
            self._año = datos[0]
            self._mes = datos[1]
            self._dia = datos[2]
            self._hora = datos[3]
            self._minuto = datos[4]
            self._segundos = datos[5]
            self._microsegundos = datos[6]
        #println("self._año=",self._año)
        #println("self._mes=", self._mes)
        #println("self._dia=", self._dia)

        #super().__setattr__("year",self._año)
        #self.replace(self._año, self._mes,self._dia,self._hora,self._minuto,self._segundos,self._microsegundos)
        #println("super().year=",super().year)
        #self.__init__(self._año, self._mes,self._dia,self._hora,self._minuto,self._segundos,self._microsegundos)
        self._datepy = datetime(self._año, self._mes,self._dia,self._hora,self._minuto,self._segundos,self._microsegundos)

        return self
    def getAño(self):
        #return self._año
        return self._datepy.year
    def getMes(self):
        #return self._mes
        return self._datepy.month
    def getDia(self):
        #return self._dia
        return self._datepy.day
    def getHora(self):
        #return self._hora
        return self._datepy.hour
    def getMinutos(self):
        #return self._minuto
        return self._datepy.minute
    def getSegundos(self):
        #return self._segundos
        return self._datepy.second
    def getMicroSegundos(self):
        #return self._microsegundos
        return self._datepy.microsecond
    def getDatepy(self):
        return self._datepy
    def getDiaDeLaSemana(self):
        return self._datepy.weekday()
    def en_año_bisiesto(self):
        return (self._año%4==0)and(self._año%100!=0 or self._año%400==0)
    """
    def esIgual(self,a):
        return self._datepy.__eq__(Date._getDatepy(a))
    def esAnterior(self,a):
        return self._datepy.__lt__(Date._getDatepy(a))
    def esAnteriorOIgual(self,a):
        return self._datepy.__le__(Date._getDatepy(a))
    def esPosterior(self,a):
        return self._datepy.__gt__(Date._getDatepy(a))
    def esPosteriorOIgual(self,a):
        return self._datepy.__ge__(Date._getDatepy(a))
    
    def aumentar(self,*a):
        if (not isEmpty(a)):
            if (not Date.esDate(a[0])) and (not esDatepy(a)) and (not esDatetimepy(a)) and (not esTimepy(a)):
                a=[Date(*a)]
            a=a[0]
            c=Date._getDatepy(a)
            println("c=",c)
            b=self._datepy.__add__(c)
            println("b=", b)
            self.set(b)

        return self
    def restar(self,*a):
        if (not isEmpty(a)):
            if (not Date.esDate(a[0])) and (not esDatepy(a)) and (not esDatetimepy(a)) and (not esTimepy(a)):
                a=[Date(*a)]
            a=a[0]
            self.set(self._datepy.__sub__(Date._getDatepy(a)))
        return self
    def getAumentado(self,*a):
        return Date(self).aumentar(*a)
    def getRestado(self,*a):
        return Date(self).restar(*a)
    """
    def __str__(self):
        return str(self._datepy)
    @staticmethod
    def esDate(a):
        return isinstance(a,Date)
    def _getDatepy(a):
        if Date.esDate(a):
            return a.getDatepy()
        return a


#var=Date().set(2000,10,12).getDiaDeLaSemana()
#print(var)
