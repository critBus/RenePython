from Utiles.MetodosUtiles.Imports.MetodosUtilesBasicos import *
from Utiles.MetodosUtiles import BD_SQLite
from Utiles.ClasesUtiles.Tipos import TipoDeConexion
from Utiles.MetodosUtiles import SQL
from Utiles.ClasesUtiles.File import File,FileTemp
class BDConexion():
    def __init__(self,tipoDeConexion,nombreBD):
        self._nombreBD=str(nombreBD)
        self._tipoDeConexion=tipoDeConexion
        self._ultimoSQL=None
        self._mostrarResultadosEnConsola=False
        #self._resultados=None

    #def getResultados(self):
    #    return self._resultados
    def drop_table_if_exist(self,nombreTabla):
        self._execute(SQL.drop_table_if_exist(nombreTabla))
        return self
    def isEmpty(self,nombreTabla,columna):
        cant=self.getCantidad(nombreTabla,columna)
        #println("cant=",cant)
        return cant==0
    def getCantidad(self,nombreTabla,columna):
        return self._execute(SQL.getCantidad(nombreTabla,columna))
    def cls(self):
        self._mostrarResultadosEnConsola=True
    def getUltimoSQL(self):
        return self._ultimoSQL
    def getNombreBD(self):
        return self._nombreBD
    def getTipoDeConexion(self):
        return self._tipoDeConexion
    def crearTablaSiNoExiste(self,nombreTabla, *args):
        self._execute(SQL.crearTablaSiNoExiste(nombreTabla, *args))
        return self
    def delete_id(self,nombreTabla,id):

        self._execute(SQL.delete_id(nombreTabla, id))
        return self
    def delete(self,nombreTabla, *args):
        """
        (nombreTabla,,whereColumna1,whereValor1,whereColumna2,whereValor2,...)
        :param nombreTabla:
        :param args:
        :return:
        """
        self._execute(SQL.delete(nombreTabla,  *args))
        return self
    def update(self,nombreTabla, paresColumnaValor, *args):
        """
        (nombreTabla,[columna,setValor1,columna2,setValor2,... ],whereColumna1,whereValor1,whereColumna2,whereValor2,...)
        :param nombreTabla:
        :param paresColumnaValor:
        :param args:
        :return:
        """
        self._execute(SQL.update(nombreTabla, paresColumnaValor, tuplaRectificada(args)))
        return self
    def update_Id(self,nombreTabla, id, *args):
        """
        (nombreTabla,id#,columna,setValor1,columna2,setValor2,... )
        :param nombreTabla:
        :param id:
        :param args:
        :return:
        """
        self._execute(SQL.update_Id(nombreTabla,id, tuplaRectificada(args)))
        return self
    def select_Distinct_Where(self,nombreTabla, *args):
        return self._execute(SQL.select_Distinct_Where(nombreTabla, tuplaRectificada(args)))
     #   self._resultados = self._execute(SQL.select_Distinct_Where(nombreTabla, tuplaRectificada(args)))
      #  return self;

    def select_Distinct_Todo(self,nombreTabla):
        return self._execute(SQL.select_Distinct_Todo(nombreTabla))
        #self._resultados = self._execute(SQL.select_Distinct_Todo(nombreTabla))
        #return self;

    def select_Distinct(self,nombreTabla, *args):
        return self._execute(SQL.select_Distinct(nombreTabla, tuplaRectificada(args)))
        #self._resultados = self._execute(SQL.select_Distinct(nombreTabla, tuplaRectificada(args)))
        #return self;

    def select_Distinct_ORDER_BY(self,nombreTabla, *args):
        return self._execute(SQL.select_Distinct_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #self._resultados = self._execute(SQL.select_Distinct_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #return self;

    def select_Distinct_Where_ORDER_BY(self,nombreTabla, *args):
        return self._execute(SQL.select_Distinct_Where_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #self._resultados = self._execute(SQL.select_Distinct_Where_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #return self;

    def select_Where_ORDER_BY(self,nombreTabla, *args):
        return self._execute(SQL.select_Where_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #self._resultados = self._execute(SQL.select_Where_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #return self;
    def select_ORDER_BY(self,nombreTabla, *args):
        return self._execute(SQL.select_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #self._resultados = self._execute(SQL.select_ORDER_BY(nombreTabla, tuplaRectificada(args)))
        #return self;
    def select_Where(self,nombreTabla, *args):
        return self._execute(SQL.select_Where(nombreTabla, *args))
        #self._resultados = self._execute(SQL.select_Where(nombreTabla, tuplaRectificada(args)))
        #return self;
    def select_forID(self,nombreTabla, id):
        res=self._execute(SQL.select_forID(nombreTabla, id))
        if not isEmpty(res):
            res=res[0]
        return res
    def select(self,nombreTabla, *args):
        return self._execute(SQL.select(nombreTabla, *args))
        #self._resultados = self._execute(SQL.select(nombreTabla,tuplaRectificada(args)))
        #return self;
    def select_Todo(self,nombreTabla):
        return self._execute(SQL.select_Todo(nombreTabla))
        #self._resultados= self._execute(SQL.select_Todo(nombreTabla))
        #return self;
    def insertar_Many_SinIdAutomatico(self,nombreTabla, filas):
        leng = 0
        if esLista(filas) and (not isEmpty(filas)) and esTupla(filas[0]):
            leng = len(filas[0])
        self._execute(SQL.insertar_Many_SinIdAutomatico(nombreTabla, leng), filas)
        return self;

    def insertar_Many_idAutomatico(self,nombreTabla, id, filas):
        leng = 0
        if esLista(filas) and (not isEmpty(filas)) and esTupla(filas[0]):
            leng = len(filas[0])
        self._execute(SQL.insertar_Many_idAutomatico(nombreTabla,id, leng), filas)
        return self;

    def insertar_Many(self,nombreTabla, filas):
        leng=0
        if esLista(filas) and (not isEmpty(filas)) and esTupla(filas[0]):
            leng=len(filas[0])
        self._execute(SQL.insertar_Many(nombreTabla,leng),filas)
        return self;
    def insertar_ConIdAutomatico(self,nombreTabla, id, *args):
        self._execute(SQL.insertar_ConIdAutomatico(nombreTabla,id, tuplaRectificada(args)))
        return self;
    def insertar_SinIdAutomatico(self,nombreTabla, *args):
        self._execute(SQL.insertar_SinIdAutomatico(nombreTabla, tuplaRectificada(args)))
        return self;
    def insertar(self,nombreTabla,*args):
        self._execute(SQL.insertar(nombreTabla,*args))
        return self;
    def crearTablaYBorrarSiExiste(self,NombreTabla,*nombre_tipos):
        self._execute(SQL.drop_table_if_exist(NombreTabla))
        self._execute(SQL.crearTabla(NombreTabla, *nombre_tipos) )
        return self;
    def crearTabla(self,NombreTabla,*nombre_tipos):
        self._execute(SQL.crearTabla(NombreTabla,tuplaRectificada(nombre_tipos)))
        #BD_SQLite.crearTabla(self.getNombreBD(),NombreTabla,tuplaRectificada(nombre_tipos))
        return self
    def _execute(self,sql,filas=None):
        self._ultimoSQL=sql
        println("execute=",sql)
        res=""
        if self.getTipoDeConexion()==TipoDeConexion.SQLITE:
            res= BD_SQLite.execute(self.getNombreBD(),sql,filas)
        if(self._mostrarResultadosEnConsola and SQL.esSelect()):
            println("resultado=",res)
        return res

def new_BDConexionSQLite(direccion):
    return BDConexion(TipoDeConexion.SQLITE,str(direccion))


