from builtins import list

from setuptools._vendor.pyparsing import White
#esTipoDeDatoSQ
from Utiles.MetodosUtiles.Imports.MetodosUtilesBasicos import *
from Utiles.ClasesUtiles.Tipos import TipoDeDatoSQL
from Utiles.ClasesUtiles.Tipos import TipoDeClasificacionSQL

CREATE="CREATE"
TABLE="TABLE"
CREATE_TABLE=CREATE+" "+TABLE
PRIMARY_KEY="PRIMARY KEY"
INSERT="INSERT"
INTO="INTO"
INSERT_INTO=INSERT+" "+INTO
VALUES="VALUES"
SELECT="SELECT"
MAX="MAX"
MIN="MIN"
AVG="AVG"
SELECT_MAX=SELECT+" "+MAX
SELECT_MIN=SELECT+" "+MIN
SELECT_AVG=SELECT+" "+AVG
FROM="FROM"
DROP="DROP"
DROP_TABLE=DROP+" "+TABLE
COPY="COPY"
WHERE="WHERE"
ORDER_BY="ORDER BY"
DISTINCT="DISTINCT"
SELECT_DISTINCT=SELECT+" "+DISTINCT
INNER_JOIN="INNER JOIN"
ON="ON"
GROUP_BY="GROUP BY"
HAVING="HAVING"
COUNT="COUNT"
SUM="SUM"
SELECT_COUNT="SELECT COUNT"
SELECT_SUM="SELECT SUM"
UPDATE="UPDATE"
SET="SET"
DELETE="DELETE"
DROP="DROP"
DROP_TABLE="DROP TABLE"
IF_EXISTS="IF EXISTS"
DROP_TABLE_IF_EXISTS=DROP_TABLE+" "+IF_EXISTS
AUTOINCREMENT="AUTOINCREMENT"
IF_NOT_EXISTS = "IF NOT EXISTS"
CREATE_TABLE_IF_NOT_EXISTS = CREATE_TABLE + " " + IF_NOT_EXISTS
ALTER="ALTER"
ALTER_TABLE=ALTER+" "+TABLE
COLUMN="COLUMN"
DROP_COLUMN=DROP+" "+COLUMN
CASCADE="CASCADE"
RENAME="RENAME"
RENAME_COLUMN=RENAME+" "+COLUMN
TO="TO"
ADD="ADD"
ADD_COLUMN=ADD+" "+COLUMN
DEFAULT="DEFAULT"

def addColumn(nombreTabla,Columna,tipo=TipoDeDatoSQL.VARCHAR,default=None,clasificacion=None):
    if default==None:
        default=tipo.getDefault()
    if clasificacion==None:
        clasificacion=""
    elif TipoDeClasificacionSQL.esTipoDeClasificacionSQl(clasificacion):
        clasificacion="  "+clasificacion.getValor()
    return ALTER_TABLE+" "+nombreTabla+" "+ADD_COLUMN+" "+Columna+" "+tipo.getValor()+" "+DEFAULT+" "+default+clasificacion
def renombrarColumna(nombreTabla,Columna,NuevoNombre):
    return ALTER_TABLE+" "+nombreTabla+" "+RENAME_COLUMN+" "+Columna+" "+TO+" "+NuevoNombre

def eliminarColumna(nombreTabla,Columna):
    return ALTER_TABLE+" "+nombreTabla+" "+DROP_COLUMN+" "+Columna+" "+CASCADE
def esSelect(sql=""):
    return sql.strip().upper().startswith(SELECT+" ")
def esSelectValor(sql=""):
    sub=sql.strip().upper()[len(SELECT + " "):]
    #println("sub="+sub)
    return starWithOR(sub, MAX, MIN, AVG, COUNT, SUM)
def getCantidadWhere(nombreTabla,*a):
    leng=len(a)
    sqlWhere = ""
    columna = ""
    pos = 0
    for i in range(leng):
        if pos == 0:
            if not isEmpty(sqlWhere):
                sqlWhere += " AND "
            sqlWhere += str(a[i])
            if isEmpty(columna):
                columna=str(a[i])
        elif pos == 1:
            sqlWhere += "='" + str(a[i]) + "'"
        pos = (pos + 1) % 2
    return SELECT_COUNT + "(" + nombreTabla + "." + columna + ") " + FROM + " " + nombreTabla + " " + WHERE + sqlWhere;
def crearTablaSiNoExiste(nombreTabla,*a):
    """
    (nombre,.. nombreColumna,TipoDeDatoSQL,capacidad#,isKeyPrimary o tipoDeClasificacionSQL)<br/>
 *  (nombre,.. nombreColumna,TipoDeDatoSQL,capacidad#)<br/> asumo que no es llave primaria
    (nombre,.. nombreColumna,capacidad#) asumo que es VARCHAR <br/>
    (nombre,.. nombreColumna) asumo que es VARCHAR(255)<br/>
    si el siguiente a nombreColumna no es un TipoDeDatoSQL asumo que es VARCHAR(255) <br/>
    si el siguiente a TipoDeDatoSQL no es un # asumo que es VARCHAR(255)  <br/>
    :param nombreTabla:
    :param a:
    :return:
    """
    return crearTabla(nombreTabla,*a).replace(CREATE_TABLE, CREATE_TABLE_IF_NOT_EXISTS, 1)
def drop_table_if_exist(nombreTabla):
    return DROP_TABLE_IF_EXISTS+" "+nombreTabla
def delete_id(nombreTabla,id):
    return delete(nombreTabla,"id",id)
def delete(nombreTabla,*args):
    """
    (nombreTabla,,whereColumna1,whereValor1,whereColumna2,whereValor2,...)
    :param nombreTabla:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sqlWhere=""
    pos = 0
    for i in range(leng):
        if pos == 0:
            if not isEmpty(sqlWhere):
                sqlWhere += " AND "
            sqlWhere += str(a[i])
        elif pos == 1:
            sqlWhere += "='" + str(a[i]) + "'"
        pos = (pos + 1) % 2
    return DELETE+" "+FROM+" "+nombreTabla+" "+WHERE+" "+sqlWhere
def update_Id(nombreTabla,id,*args):
    """
    (nombreTabla,id#,columna,setValor1,columna2,setValor2,... )
    :param nombreTabla:
    :param id:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    paresColumnaValor=[]
    for i in a:
        paresColumnaValor.append(i)
    return update(nombreTabla,paresColumnaValor,"id",id)
def update(nombreTabla,paresColumnaValor,*args):
    """
    (nombreTabla,[columna,setValor1,columna2,setValor2,... ],whereColumna1,whereValor1,whereColumna2,whereValor2,...)
    :param nombreTabla:
    :param paresColumnaValor:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sqlSet = ""
    sqlWhere=""

    leng2=len(paresColumnaValor)
    pos=0
    for i in range(leng2):
        if pos==0:
            if not isEmpty(sqlSet):
                sqlSet+=" , "
            sqlSet+=str(paresColumnaValor[i])
        elif pos==1:
            sqlSet+="='"+str(paresColumnaValor[i])+"'"
        pos=(pos+1)%2
    pos=0
    for i in range(leng):
        if pos==0:
            if not isEmpty(sqlWhere):
                sqlWhere+=" AND "
            sqlWhere+=str(a[i])
        elif pos==1:
            sqlWhere+="='"+str(a[i])+"'"
        pos = (pos + 1) % 2
    return UPDATE+" "+nombreTabla+" "+SET+" "+sqlSet+" "+WHERE+" "+sqlWhere
def getSuma(nombreTabla,columna):
    return SELECT_SUM+"("+nombreTabla+"."+columna+") "+FROM+" "+nombreTabla

def getCantidad(nombreTabla,columna):
    return SELECT_COUNT+"("+nombreTabla+"."+columna+") "+FROM+" "+nombreTabla

def select_Distinct_Group_By_By_Having(nombreTabla,columnas,grupBy,heavinColumna,heavinValor):
    return select_Group_By_Having(nombreTabla,columnas,grupBy,heavinColumna,heavinValor).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Group_By_Having(nombreTabla,columnas,grupBy,heavinColumna,heavinValor):
    return select_Group_By(nombreTabla,columnas,grupBy)+" "+HAVING+" "+heavinColumna+"="+heavinValor
def select_Distinct_Group_By(nombreTabla,columnas,grupBy):
    return select_Group_By(nombreTabla,columnas,grupBy).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Group_By(nombreTabla,columnas,grupBy):
    """
    (nombreTabla,[]columnas,grupBy)
    :param nombreTabla:
    :param args:
    :return:
    """
    return select(nombreTabla,tuple(columnas))+" "+GROUP_BY+" "+grupBy
def select_Distinct_Where_Inner_Join(*args):
    return select_Where_Inner_Join( tuplaRectificada(args)).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Where_Inner_Join(*args):
    """
    (nombreTabla1,[]columnas,nombreTabla2,columnas[],...,[[columna,valor,columna2,valor2,...]])
    si no se pone columnas asumo que son todas<br/>
    [[]]una lista dentro de otra lista
    <br/> si se pone del lado de la columna solo el nombre de la columna busco entre lass columnas seleccionadas<br/>
    de las tablas y a la enlaso con la primera coincedencia de un nombre de columna seleccionada con su nombreTabla<br/>
    si no hay coincidencias pq la tabla fue * solo la pongo sola "columna='algo'"<br/>
    puedes especificar a que tabla pertenece esa columna "nombreTabla.columna='algo'"<br/>
    del lado de los valores tambien se puede especificar un columna simpre que se ponga el nombreTabla<br/>
    seguido de un punto "columna='nombreTabla.columna2'"

    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sql = ""
    nombreTablas=[]
    columnasSeleccionadas=[]
    def getNombreTablaAlQuePertenece(arg,admitirContiene):
        b=str(arg)
        leng3=len(nombreTablas)
        for i in range(leng3):
            #println("b=",b," nombreTablas[i]=",nombreTablas[i]," columnasSeleccionadas[i]=",columnasSeleccionadas[i])
            #println("nombreTablas[i]+'.'=",nombreTablas[i]+'.')
            #println("b.startswith(nombreTablas[i]+'.')=",b.startswith(nombreTablas[i]+"."))
            #println("admitirContiene=",admitirContiene)
            #println("contiene(columnasSeleccionadas[i],b)=",contiene(columnasSeleccionadas[i],b))
            #println("(admitirContiene and contiene(columnasSeleccionadas[i],b))=",admitirContiene and contiene(columnasSeleccionadas[i],b))
            #println("(b.startswith(nombreTablas[i]+'.') or (admitirContiene and contiene(columnasSeleccionadas[i],b)))=",(b.startswith(nombreTablas[i]+".") or (admitirContiene and contiene(columnasSeleccionadas[i],b))))
            if b.startswith(nombreTablas[i]+".") or (admitirContiene and contiene(columnasSeleccionadas[i],b)):
                #println("return i=",i)
                return i;
        #println("return -1")
        return -1;
    def recorrerWhere(lista=[],sql=""):
        #global sql

        leng2=len(lista)
        pos2 = 0
        for i in range(leng2):
                nombreTablaAlQuePertenece=-1
                if pos2==0:
                    if not isEmpty(sql):
                        sql+=" AND "
                    nombreTablaAlQuePertenece=getNombreTablaAlQuePertenece(lista[i],True)
                    ini = ""
                    if nombreTablaAlQuePertenece!=-1 :
                        if not lista[i].startswith(nombreTablas[nombreTablaAlQuePertenece]+"."):
                            ini=nombreTablas[nombreTablaAlQuePertenece] + "."
                    sql +=ini +lista[i]
                elif pos2==1:
                    sql+=" = "
                    #println("**********lista[i]=",lista[i])
                    nombreTablaAlQuePertenece=getNombreTablaAlQuePertenece(lista[i],False)
                    #println("nombreTablaAlQuePertenece=",nombreTablaAlQuePertenece)
                    if nombreTablaAlQuePertenece!=-1:
                        sql+=lista[i]
                    else:
                        sql+="'"+lista[i]+"'"
                pos2 = (pos2 + 1) % 2


        return sql
    pos = 0
    for i in range(leng):
        if pos == 1:
            if esLista(a[i]):
                if not isEmpty(a[i]):
                    if esLista(a[i][0]):
                        sql=recorrerWhere(a[i][0],sql)
                        break
                columnasSeleccionadas.append(a[i])
            else:
                columnasSeleccionadas.append([])
                pos=0
        if pos == 0:
            if esLista(a[i]):
                if not isEmpty(a[i]):
                    if esLista(a[i][0]):
                        sql=recorrerWhere(a[i][0],sql)
                        break
                else:
                    break
            nombreTablas.append(a[i])
        pos = (pos + 1) % 2
    listaArgs=[]
    leng4=len(nombreTablas)
    for i in range(leng4):
        listaArgs.append(nombreTablas[i])
        listaArgs.append(columnasSeleccionadas[i])
    #print(tuple(listaArgs))
    return select_Inner_Join(tuple(listaArgs))+" "+WHERE+" "+sql
    #return "hola"

def select_Distinct_Inner_Join(*args):
    return select_Inner_Join( tuplaRectificada(args)).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Inner_Join(*args):
    """
    (nombreTabla1,[]columnas,nombreTabla2,columnas[],...)si no se pone columnas asumo que son todas
    :param nombreTabla:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sql = ""
    sqlNombresTablas=""
    nombreTablaActual=""
    pos=0
    for i in range(leng):
        if pos==1:
            if esLista(a[i]):
                leng2=len(a[i])
                if leng2==0:
                    if not isEmpty(sql):
                        sql += " , "
                    sql += nombreTablaActual + ".*"
                else:
                    for j in range(leng2):
                        if not isEmpty(sql):
                            sql+=" , "
                        sql+=nombreTablaActual+"."+a[i][j]
            else:
                if not isEmpty(sql):
                    sql += " , "
                sql += nombreTablaActual + ".*"
                pos=0
        if pos==0:
            if not isEmpty(sqlNombresTablas):
                sqlNombresTablas+=" , "
            sqlNombresTablas+=a[i]
            nombreTablaActual=a[i]
        pos=(pos+1)%2
    if pos==1:
        if not isEmpty(sql):
            sql += " , "
        sql += nombreTablaActual + ".*"
    return SELECT+" "+sql+" "+FROM+" "+sqlNombresTablas


def select_Distinct_Where(nombreTabla,*args):
    return select_Where(nombreTabla, tuplaRectificada(args)).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Distinct_Todo(nombreTabla):
    return select_Todo(nombreTabla).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Distinct(nombreTabla,*args):
    return select(nombreTabla, tuplaRectificada(args)).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Distinct_ORDER_BY(nombreTabla,*args):
    return select_ORDER_BY(nombreTabla, tuplaRectificada(args)).replace(SELECT + " ", SELECT_DISTINCT + " ", 1)
def select_Distinct_Where_ORDER_BY(nombreTabla,*args):
    return select_Where_ORDER_BY(nombreTabla,tuplaRectificada(args)).replace(SELECT+" ",SELECT_DISTINCT+" ",1)
def select_Where_ORDER_BY(nombreTabla,*args):
    """
    (nombreTabla,columnas[],where[pares .. Columna-Valor],columnas por los que ordenar)
    (nombreTabla,where[pares .. Columna-Valor],columnas por los que ordenar)
    :param nombreTabla:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sql = ""
    inicioDeColumnas = 0
    sqlSelect = ""
    if leng > 0:
        if esLista(a[0]):
            inicioDeColumnas = 1
            if esLista(a[1]):
                inicioDeColumnas = 2
                lista2 = list(a[1])
                lista2.insert(0, a[0])
                sqlSelect = select_Where(nombreTabla, tuple(lista2))
            else:
                sqlSelect = select_Where(nombreTabla, tuple(a[0]))
        else:
            sqlSelect = select_Todo(nombreTabla)
        for i in range(inicioDeColumnas, leng):
            if i != inicioDeColumnas:
                sql += " , "
            sql += str(a[i])
    return sqlSelect + " " + ORDER_BY + " " + sql


def select_ORDER_BY(nombreTabla,*args):
    """
    (nombreTabla,columnas[],where[pares .. Columna-Valor],columnas por los que ordenar)
    (nombreTabla,columnas[],columnas por los que ordenar)
    (nombreTabla,columnas por los que ordenar) selecciona todas las columnas
    :param nombreTabla:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sql = ""
    inicioDeColumnas = 0
    sqlSelect = ""
    if leng > 0:
        if esLista(a[0]):
            inicioDeColumnas = 1
            if esLista(a[1]):
                inicioDeColumnas = 2
                lista2=list(a[1])
                lista2.insert(0,a[0])
                sqlSelect=select_Where(nombreTabla,tuple(lista2))
            else:
                sqlSelect=select(nombreTabla,tuple(a[0]))
        else:
            sqlSelect=select_Todo(nombreTabla)
        for i in range(inicioDeColumnas,leng):
            if i!=inicioDeColumnas:
                sql+=" , "
            sql+=str(a[i])
    return sqlSelect+" "+ORDER_BY+" "+sql
def select_forID(nombreTabla,id):
    return select_Where(nombreTabla,"id",id)
def select_Where(nombreTabla,*args):
    """
    (nombreTabla,columnas[],pares .. Columna-Valor)
    (nombreTabla,pares .. Columna-Valor)
    :param nombreTabla:
    :param args:
    :return:
    """
    a = tuplaRectificada(args)
    leng = len(a)
    sql = ""
    inicioDePares=0
    sqlSelect=""
    if leng>0:
        if esLista(a[0]):
            inicioDePares=1
            if not isEmpty(a[0]):
                sqlSelect=select(nombreTabla,tuple(a[0]))
        if isEmpty(sqlSelect):
            sqlSelect=select_Todo(nombreTabla)
        pos=0
        for i in range(inicioDePares,leng):
            if i!=inicioDePares and pos==0:
                sql+=" AND "
            if pos==0:
                sql+=str(a[i])
            elif pos==1:
                sql+=" = '"+str(a[i])+"'"
            pos=(pos+1)%2
    return sqlSelect+" "+WHERE+" "+sql


def select_Todo(nombreTabla):
    return select(nombreTabla,"*")
def select(nombreTabla,*args):
    a=tuplaRectificada(args)
    leng=len(a)
    sql=""
    for i in range(leng):
        if i!=0:
            sql+=" , "
        sql+=str(a[i])
    return SELECT+" "+sql+" "+FROM+" "+nombreTabla

def copyEnTXT(nombreTabla,direccion):
    if not isEmpty(direccion):
        if not direccion.endswith(".txt"):
            direccion+=".txt"
        return COPY+" "+nombreTabla+" "+FROM+" "+direccion
def getPoint(X,Y):
    return "("+str(X)+","+str(Y)+")"
def getDate(año,mes,dia):
    return str(año)+"-"+str(mes)+"-"+str(dia)

def dropTable(nombreTabla):
    return DROP_TABLE+" "+nombreTabla

def getIdCorrespondiente(nombreTabla,id="id"):
    return "("+getValorMaximo(nombreTabla,id)+")+1"
def getValorPromedio(nombreTabla,columna):
    return SELECT_AVG+"("+nombreTabla+"."+columna+") "+FROM+" "+nombreTabla
def getValorMinimo(nombreTabla,columna):
    return SELECT_MIN+"("+nombreTabla+"."+columna+") "+FROM+" "+nombreTabla
def getValorMaximo(nombreTabla,columna):
    return SELECT_MAX+"("+nombreTabla+"."+columna+") "+FROM+" "+nombreTabla
def insertar_ConIdAutomatico(nombreTabla,id,*args):
    """
    (nombreTabla,valores una sola fila completa)
    (nombreTabla,[]columnas,valores)<br/>
    si no lo tiene pone el id de forma automatica con el nombre del argumento
    :param nombreTabla:
    :param id:
    :param args:
    :return:
    """
    return __insertar(nombreTabla, True, id, tuplaRectificada(args))
def insertar_SinIdAutomatico(nombreTabla,*args):
    """
    (nombreTabla,valores una sola fila completa)
    (nombreTabla,[]columnas,valores)<br/>
    es nuestra responsabiladad asegurarnos de que almenos uno de los valores sea una llave
    :param nombreTabla:
    :param args:
    :return:
    """
    return __insertar(nombreTabla, False, "", tuplaRectificada(args))
def insertar(nombreTabla,*args):
    """
    (nombreTabla,valores una sola fila completa)
    (nombreTabla,[]columnas,valores)<br/>
    si no lo tiene pone el id de forma automatica
    :param nombreTabla:
    :param args:
    :return:
    """
    return __insertar(nombreTabla,True,"id",tuplaRectificada(args))
def __insertar(nombreTabla,idAutomatico,nombreId,*args):
    """
    (nombreTabla,valores una sola fila completa)
    (nombreTabla,[]columnas,valores)
    :param nombreTabla:
    :param args:
    :return:
    """
    #cada []leng comienza la sigiente fila
    sql=""
    sqlColumnas=""
    a=tuplaRectificada(args)
    leng=len(a)
    listaColumnas=None
    inicioDeValores=0
    if leng>0:
        if esLista(a[0]):
            listaColumnas=a[0]
            leng2=len(listaColumnas)
            for i in range(leng2):
                if i!=0:
                    sqlColumnas+=" , "
                sqlColumnas+=listaColumnas[i]
            inicioDeValores=1
        for i in range(inicioDeValores,leng):
            if i!=inicioDeValores:
                sql+=" , "
            sql+=" '"+str(a[i])+"' "
    if idAutomatico:
        if isEmpty(nombreId):
            nombreId="id"
        #sql="("+getIdCorrespondiente(nombreTabla,nombreId)+") , "+sql
        sql = " NULL , " + sql
        if not isEmpty(sqlColumnas):
            sqlColumnas=nombreId+" , "+sqlColumnas

    if not isEmpty(sqlColumnas):
        sql= INSERT_INTO+" "+nombreTabla+" ( "+sqlColumnas+" ) "+VALUES+" ( "+sql+" ) "
    else:
        sql=INSERT_INTO+" "+nombreTabla+" "+VALUES+" ( "+sql+" ) "
    return sql
def insertar_Many_SinIdAutomatico(nombreTabla,cantidadDeColumnas):
    return __insertar_Many(nombreTabla, False, "", cantidadDeColumnas)
def insertar_Many_idAutomatico(nombreTabla,id,cantidadDeColumnas):
    return __insertar_Many(nombreTabla,True,id,cantidadDeColumnas)
def insertar_Many(nombreTabla,cantidadDeColumnas):
    return __insertar_Many(nombreTabla,True,"id",cantidadDeColumnas)
def __insertar_Many(nombreTabla,idAutomatico,nombreId,cantidadDeColumnas):
    sql =""
    for i in range(cantidadDeColumnas):
        if i!=0:
            sql+=" , "
        sql+="?"
    if idAutomatico:
        #if isEmpty(nombreId):
         #   nombreId="id"
        #sql="("+getIdCorrespondiente(nombreTabla,nombreId)+") , "+sql
        sql = " NULL , " + sql
    return INSERT_INTO + " " + nombreTabla + " " + VALUES + " ( " + sql + " ) "

def crearTabla(nombreTabla,*nombre_tipos):
    """
    (nombre,.. nombreColumna,TipoDeDatoSQL,capacidad#,isKeyPrimary o tipoDeClasificacionSQL)<br/>
 *  (nombre,.. nombreColumna,TipoDeDatoSQL,capacidad#)<br/> asumo que no es llave primaria
    (nombre,.. nombreColumna,capacidad#) asumo que es VARCHAR <br/>
    (nombre,.. nombreColumna) asumo que es VARCHAR(255)<br/>
    si el siguiente a nombreColumna no es un TipoDeDatoSQL asumo que es VARCHAR(255) <br/>
    si el siguiente a TipoDeDatoSQL no es un # asumo que es VARCHAR(255)  <br/>
    :param NombreTabla:
    :param nombre_tipos:
    :return:
    """

    a=tuplaRectificada(nombre_tipos)
    leng=len(a)

    #if leng>0 and nombre_tipos[0]=='valor1':
        #println("tipos=",a)
    sql=""
    tipoAnterior=None
    pos=0
    tieneClavePrimaria=False
    for i in a:
        pos=pos%4

        if pos==3:
            if esBool(i):
                if i:
                    sql += strg(" ", PRIMARY_KEY)
                    tieneClavePrimaria=True
            elif TipoDeClasificacionSQL.esTipoDeClasificacionSQl(i):
                sql += strg(" ", i.getValor())
                if TipoDeClasificacionSQL.esLlave(i):
                    tieneClavePrimaria = True

            else:
                pos=0
            sql+=" , "
            tipoAnterior=None

        if pos==2:
            if esInt(i):
                sql+=strg("(",i,")")
            else:
                if tipoAnterior==TipoDeDatoSQL.VARCHAR:
                    sql += strg("(255)")
                if esBool(i):
                    if i:
                        sql += strg(" ", PRIMARY_KEY)
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                elif TipoDeClasificacionSQL.esTipoDeClasificacionSQl(i):
                    sql += strg(" ", i.getValor())
                    if TipoDeClasificacionSQL.esLlave(i):
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                else:
                    pos=0
                    sql += " , "



        if pos==1:
            tipo = None
            if TipoDeDatoSQL.esTipoDeDatoSQL(i):
                tipo=i
            if tipo!=None:
                sql += strg(" ",i.getValor())
                tipoAnterior=tipo

            elif esInt(i):
                #println("i=",i)
                tipo=TipoDeDatoSQL.VARCHAR
                sql += strg(" ", tipo.getValor(),"(",i,")")
                tipoAnterior=tipo
                pos=3
                continue
            else:
                tipo = TipoDeDatoSQL.VARCHAR
                sql +=strg(" ",tipo.getValor(),"(255)")
                tipoAnterior = tipo
                if esBool(i):
                    if i:
                        sql += strg(" ", PRIMARY_KEY)
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                elif TipoDeClasificacionSQL.esTipoDeClasificacionSQl(i):
                    sql += strg(" ", i.getValor())
                    if TipoDeClasificacionSQL.esLlave(i):
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                else:
                    pos=0
                    sql += " , "

        if pos==0:
            #print("pos 0")
            sql += strg(" ",i)
        pos+=1


    if pos == 1:
        tipo = TipoDeDatoSQL.VARCHAR
        sql += strg(" ", tipo.getValor(), "(255) ")


    elif pos==2:
        if tipoAnterior==TipoDeDatoSQL.VARCHAR:
            sql += strg("(255)")
    if endsWithOR(sql,", ",","):
        sql=sql[:sql.rfind(",")]

    if (not tieneClavePrimaria) and (not contiene(sql," id ")):
        add=""
        if not isEmpty(sql.strip()):
            add=" , "

        sql = " id " + TipoDeDatoSQL.INTEGER.getValor() + " " + PRIMARY_KEY+" "+AUTOINCREMENT +add+sql

    return CREATE_TABLE+" "+nombreTabla+" ( "+sql+" ) "

"""
def crearTabla(nombreTabla,*nombre_tipos):
   
    a=tuplaRectificada(nombre_tipos)
    leng=len(a)

    sql=""
    tipoAnterior=None
    pos=0
    tieneClavePrimaria=False
    for i in a:
        pos=pos%4

        if pos==3:
            if esBool(i):
                if i:
                    sql += strg(" ", PRIMARY_KEY)
                    tieneClavePrimaria=True
            else:
                pos=0
            sql+=" , "
            tipoAnterior=None

        if pos==2:
            if esInt(i):
                sql+=strg("(",i,")")
            else:
                if tipoAnterior==TipoDeDatoSQL.VARCHAR:
                    sql += strg("(255)")
                if esBool(i):
                    if i:
                        sql += strg(" ", PRIMARY_KEY)
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                else:
                    pos=0
                    sql += " , "



        if pos==1:
            tipo = None
            if TipoDeDatoSQL.esTipoDeDatoSQl(i):
                tipo=i
            if tipo!=None:
                sql += strg(" ",i.getValor())
                tipoAnterior=tipo

            elif esInt(i):
                #println("i=",i)
                tipo=TipoDeDatoSQL.VARCHAR
                sql += strg(" ", tipo.getValor(),"(",i,")")
                tipoAnterior=tipo
                pos=3
                continue
            else:
                tipo = TipoDeDatoSQL.VARCHAR
                sql +=strg(" ",tipo.getValor(),"(255)")
                tipoAnterior = tipo
                if esBool(i):
                    if i:
                        sql += strg(" ", PRIMARY_KEY)
                        tieneClavePrimaria = True
                    sql += " , "
                    pos = 0
                    tipoAnterior = None
                    continue
                else:
                    pos=0
                    sql += " , "

        if pos==0:
            #print("pos 0")
            sql += strg(" ",i)
        pos+=1


    if pos == 1:
        tipo = TipoDeDatoSQL.VARCHAR
        sql += strg(" ", tipo.getValor(), "(255) ")


    elif pos==2:
        if tipoAnterior==TipoDeDatoSQL.VARCHAR:
            sql += strg("(255)")
    if endsWithOR(sql,", ",","):
        sql=sql[:sql.rfind(",")]

    if (not tieneClavePrimaria) and (not contiene(sql," id ")):
        #sql=" id "+TipoDeDatoSQL.INTEGER.getValor()+" "+PRIMARY_KEY+" , "+sql
        sql = " id " + TipoDeDatoSQL.INTEGER.getValor() + " " + PRIMARY_KEY+" "+AUTOINCREMENT + " , " + sql
    return CREATE_TABLE+" "+nombreTabla+" ( "+sql+" ) "

"""