import ctypes
from datetime import datetime,date,time
def strg(*a):
    sal = "";
    for i in a:
        sal += str(i)
    return sal

def println(*a):
    sal="";
    for i in a:
        sal+=str(i)
    print(sal)

def esInt(a):
    if esBool(a):
        return False
    return isinstance(a, int)
def esFloat(a):
    return isinstance(a, float)
def esBool(a):
    return isinstance(a,bool)

def esIntOR(*a):
    for i in a:
        if(esInt(i)):
            return True
    return False
def esBoolOR(*a):
    for i in a:
        if(esBool(i)):
            return True
    return False
def esFloatOR(*a):
    for i in a:
        if(esFloat(i)):
            return True
    return False
def esStringOR(*a):
    for i in a:
        if(esString(i)):
            return True
    return False



def esIntAll(*a):
    for i in a:
        if not esInt(i):
            return False
    return True
def esBoolAll(*a):
    for i in a:
        if not esBool(i):
            return False
    return True
def esFloatAll(*a):
    for i in a:
        if not esFloat(i):
            return False
    return True
def esStringAll(*a):
    for i in a:
        if not esString(i):
            return False
    return True

def ln(a):
	return str("\n"+str(a))

def lne(a):
	return str(str(a)+"\n")

def esString(a):
	return isinstance(a,str)

def esFuncion(a):
	return str(type(a))=="<class 'function'>"

def esLista(a):
	return isinstance(a,list)	
def esTupla(a):
    return isinstance(a,tuple)
def esSet(a):
    return isinstance(a,set)
def esMap(a):
    return isinstance(a,dict)
def elminarLn(lista):
    if esLista(lista):
        listaSalida=[]
        for x in lista:
            listaSalida.append(x.replace("\n",""))
        else:
            return listaSalida
    
def addLneSiEsNecesario(lista):
    if esLista(lista):
        listaSalida=[]
        for x in lista:
            line=""
            if x.endswith("\n"):#contiene(x,"\n")
            	line=x
            else:
            	line=lne(x)
            listaSalida.append(line)
        else:
            return listaSalida

def contiene(palabra,subContenido):
    if esString(palabra):
        return palabra.find(subContenido)!=-1
    if esLista(palabra) or esTupla(palabra):
        try:
            return palabra.index(subContenido) != -1
        except:
            return False
def contieneOR(palabra,*subContenido):
    if len(subContenido)==1 and esLista(subContenido[0]):
        subContenido=subContenido[0]
    for i in subContenido:
        if contiene(palabra,i):
            return True
    return False


def tuplaRectificada(a):
    if esTupla(a) and len(a)==1 and esTupla(a[0]):
        return a[0]
    return a

def endsWithOR(a,*args):
    """
    args son las terminaciones
    :param a:
    :param args:
    :return:
    """
    b=tuplaRectificada(args)
    for i in b:
        if a.endswith(i):
            return True
    return False
def starWithOR(a,*b):
    """
    args son las terminaciones
    :param a:
    :param b:
    :return:
    """
    for i in b:
        if a.startswith(i):
            return True
    return False
def isEmpty(a):
    if esString(a) or esLista(a) or esTupla(a):
        return len(a)==0
def esMatrisLista(a):
    return esLista(a) and len(a)>0 and esLista(a[0])
def getScreenSize():
    user32 = ctypes.windll.user32
    user32.SetProcessDPIAware()
    anchoPantalla, altoPantalla = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    return (anchoPantalla,altoPantalla)
def Or(a,*b):
    for i in b:
        if i==a:
            return True
    return False
def esDatepy(a):
    return isinstance(a,date)
def esDatetimepy(a):
    return isinstance(a,datetime)
def esTimepy(a):
    return isinstance(a,time)
def seT(a=[],indice=None,objeto=None):
    if esLista(a):
        res= a.pop(indice)
        a.insert(indice,objeto)
        return res
    if esTupla(a):
        a=list(a)
        seT(a)
        return a