class ModeloDeApiBD:
    def __init__(self,idkey: int = None, apibd=None):
        self.idkey = idkey
        self.apibd = apibd