class Utilizar():
    def __init__(self,a):
        self.a=a
    def utilizar(self):
        pass