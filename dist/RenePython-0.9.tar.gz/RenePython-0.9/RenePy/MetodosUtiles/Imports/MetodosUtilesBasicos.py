from  RenePy.MetodosUtiles.MetodosUtiles import ln,lne,esFuncion,esLista,esString,esInt,esFloat,esBool,esStringOR,esIntOR,esFloatOR,esBoolOR,esStringAll,esIntAll,esFloatAll,esBoolAll,esTupla,esSet,esMap,tuplaRectificada,println,strg,endsWithOR,contiene,isEmpty,starWithOR,esMatrisLista,contieneOR,getScreenSize,Or,esDatepy,esDatetimepy,esTimepy,seT,esListaAll,verDicionario,verLista,toBool,addSiNoContiene,And,esTimedelta,getExceptionStr,verException,toFloat,toInt,replaceAll


"""
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import ln
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import lne
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import esString
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import esFuncion
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import esLista
from  RenePython.Utiles.MetodosUtiles.MetodosUtiles import contiene
"""
"""
from RenePython.Utiles.MetodosUtiles import MetodosUtiles


def ln(a):
	return MetodosUtiles.ln(a)

def lne(a):
	return MetodosUtiles.lne(a)

def esString(a):
	return MetodosUtiles.esString(a)

def esFuncion(a):
	return MetodosUtiles.esFuncion(a)

def esLista(a):
	return MetodosUtiles.esLista(a)	

""" 